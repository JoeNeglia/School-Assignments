import java.util.ArrayList;
public class Serial extends Circuit {
	
	ArrayList<Circuit> serial;
	
	public Serial() {
		
		serial = new ArrayList < Circuit >();
	}
	
	public void add(Circuit a) {
		serial.add(a);
	}
	
	@Override
	public double getResistance() { 
		
		double totalResistance = 0; 
		
		for(Circuit circuit: serial) {
			totalResistance += circuit.getResistance();
		}
		return totalResistance;
	}
	
	

}
