/**
 * 
 * @author joeneglia
 *
 */
public class Circuit {

	//base value of resistance
	double resistance = 0;
	
	//the first get resistance method in the superclass
	public double getResistance() {
		return 0;
	}
	
	
	
}
