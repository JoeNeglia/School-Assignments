import java.util.ArrayList;

public class Parallel extends Circuit {
	
	ArrayList<Circuit> parallel;

	public Parallel() {
		parallel = new ArrayList<Circuit>();
	}
	
	public void add(Circuit a) {
		parallel.add(a);
	}
	
	@Override
	public double getResistance() {
		double totalResistance = 0;
		
		for(Circuit circuit: parallel) {
			totalResistance += (1/circuit.getResistance());
		}
		return 1/totalResistance;
	}
	
	



}
