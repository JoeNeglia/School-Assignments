/**
 * A class to run tests on the Circuit class and subclasses
 * @author Horstman
 * @version 02/06/2014
 *  
 */

public class CircuitDemo
{	/**
	method that implements tests for Circuit class and sublclasses
	@param args - Not Used.
 	*/
	
   public static void main(String[] args)
   {
      Parallel circuit1 = new Parallel();
      circuit1.add(new Resistor(100));
      Serial circuit2 = new Serial();
      circuit2.add(new Resistor(100));
      circuit2.add(new Resistor(200));
      circuit1.add(circuit2);
      System.out.println("Combined resistance: " + circuit1.getResistance());
      System.out.println("Expected: 75.0");
      
      //adding more circuits
      Serial c1 = new Serial();
      c1.add(new Resistor(200));
      c1.add(new Resistor(100));
      System.out.println("c1 total resistance: " + c1.getResistance());
      Parallel c2 = new Parallel();
      c2.add(new Resistor(100));
      c2.add(new Resistor(100));
      System.out.println("c2 total resistance: " + c2.getResistance());
      Serial c3 = new Serial();
      c3.add(c1);
      c3.add(c2);
      System.out.println("c3 total resistance: " + c3.getResistance());
     
   }
}

