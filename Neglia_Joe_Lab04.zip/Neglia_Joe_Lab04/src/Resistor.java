
public class Resistor extends Circuit {
	
	
	public Resistor(double r) {
		resistance = r;
	}
	
	@Override
	public double getResistance() {
		return resistance;
	}
}
