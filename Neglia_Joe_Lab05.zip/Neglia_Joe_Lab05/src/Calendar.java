import java.util.ArrayList;
import java.util.List;

public class Calendar {

    private ArrayList<Appointment> appointments;

    public Calendar() {
        appointments = new ArrayList<>();
    }

    /**

     * A method to add an appointment to the calendar

     * @param apt – the appointment object to add to the calendar.

     */

    public void add(Appointment apt) {
        this.appointments.add(apt);
    }

    /**

     * A method to remove an appointment from the calendar.

     * This method uses the occursOn() method from the public

     * interface for the Appointment class. Therefore, if parameters

     * are entered that occur after a start date for a given Daily

     * appointment

     * the Daily appointment will be removed as well. (Because occursOn() * will return true in this case). This is a limitation we will

     * accept for now.

     * @param year - the year of the appointment to remove

     * @param month - the month of the appointment to remove

     * @param day - the day of the appointment to remove

     */

    public void remove(int year, int month, int day) {

        ArrayList<Appointment> temp = new ArrayList<>();
        for (Appointment appointment : appointments){
            if(appointment.occursOn(year,month,day)){
                temp.add(appointment);
            }
        }
        appointments.removeAll(temp);
    }

    /**

     * Method to return a string representation of this Calendar object.

     * Overrides the Object method toString (see page 448 in text).

     * (also see page 453 Special Topic 9.6)

     * @return a String representation of the Calendar object.

     */

    public String toString() {

        String ret = "";

        for (Appointment appointment : appointments){
            ret = ret + "\n" + appointment;
        }
        return ret;
    }

}