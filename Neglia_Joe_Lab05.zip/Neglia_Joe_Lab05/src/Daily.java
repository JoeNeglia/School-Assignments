
public class Daily extends Appointment {
	
	//daily constructor
    public Daily(int year, int month, int day, String description) {
        super(year, month, day, description);
    }

    @Override
    public String toString() {
        return  "Daily [" + this.getDescription() + " Date: " + this.getMonth()
                + "/" + this.getDay() + "/" + this.getYear() + "]";
    }
}