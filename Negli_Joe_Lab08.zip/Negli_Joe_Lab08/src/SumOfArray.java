public class SumOfArray {
 
     private static int calculateSum(int array[], int a) {
 
         //base or terminating condition
         if (a <= 0) {
            return 0;
          }
 
          //Calling method recursively
          return calculateSum(array, a - 1) + array[a - 1];
      }
 
      public static void main(String[] args) {
 
         int arr[] = {10, 10, 10, 10, 10};
         int sum = calculateSum(arr, arr.length);
 
          System.out.println(sum);
      }
 
}
