
import java.util.Scanner;

public class SquareRootComputer {
    public static void main(String[] args) throws Exception {
    	
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number:");
        double num = scanner.nextDouble();
        
        double sqrt = squareRoot(num);
        System.out.printf("The square root of %.3f is %.5f", num, sqrt);
        System.out.printf("\nExpected value: %.5f\n", sqrt);
        scanner.close();
    }

    public static double squareRoot(double x) {
    	
        double g = x/2;
        //uses squareRootGuess recursively
        double sqrt = squareRootGuess(x, g);
        
        return sqrt;
    }

    public static double squareRootGuess(double x, double g) {
    	//equation provided
        if (Math.abs((g * g) - (x)) < 0.0001) {
            return g;
        } 
        else {
            return squareRootGuess(x, (g + (x / g)) / 2);
        }
    }
}