
import java.io.*;
import java.util.Scanner;

public class CapacitorVoltage {
	
    private static String readFile(String filename) throws IOException,FileNotFoundException {
        BufferedReader reader;
        String line = "";

            FileReader fileReader = new FileReader(
                    filename);
            reader = new BufferedReader(fileReader);
            line = reader.readLine();

            reader.close();

        return line;
    }
    
    public static void main(String []args) throws IOException {
        // creates rc.text file with param.txt
    	boolean validFileProvided = false;
        Scanner myInput = new Scanner( System.in );
        String fileName = "params.txt";
        String params = "";
        while(!validFileProvided) {
            try {
                params = readFile(fileName);
                validFileProvided = true;
            } catch (FileNotFoundException fileNotFoundException) {
                validFileProvided = false;
                System.out.println("Enter Valid Filename : ");
                fileName = myInput.nextLine();
            }
        }

        //finds the voltage
        String []data = params.split(" ");
        double B = Double.parseDouble(data[0]);
        double R = Double.parseDouble(data[1]);
        double C = Double.parseDouble(data[2]);
        double tStart = Double.parseDouble(data[3]);
        double tEnd = Double.parseDouble(data[4]);

        double diff = (tEnd-tStart)/100;

        FileWriter myWriter = new FileWriter("rc.txt");

        for(int t = 0; t <= tEnd; t += diff){
            double expValue = (-1) * t /(R*C);
            double voltage = B * (1 - Math.exp(expValue));
            myWriter.write(t + " " + voltage + "\n");
        }
        myWriter.close();
    }
    
}
