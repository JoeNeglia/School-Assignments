
public class PrimeSequence implements Sequence {
	
	//static variable for keeping last prime number which is found though next() method
	static int prime=1; 
	
	//isprime() method for checking if n is prime or not
	boolean isprime(int n){
		for(int i = 2; i * i <= n; i++){
			if(n%i == 0)
				return false;
		}
		return true;
	}
	
	//next method for getting next prime number
	public int next(){
		
		for(int i = prime + 1; i > 1; i++){
			if(isprime(i)){
				prime = i;
				//finds next prime number then assigns it to prime variable and break the loop
				break; 
			}
		}
		// return new prime number
		return prime; 
	}
	
	public static void main (String[] args) {

		int n = 1000; 
		
		//object of primeSequence
		PrimeSequence p = new PrimeSequence(); 
		
		//loop for finding n prime numbers 
		for(int i = 1; i <= n; i++){
			System.out.println(i + "th call : " + p.next());
		}
		
	}
}
	