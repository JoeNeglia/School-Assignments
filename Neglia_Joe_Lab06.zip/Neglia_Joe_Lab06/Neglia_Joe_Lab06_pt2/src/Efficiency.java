
public interface Efficiency {
	double getEfficiency();
}
