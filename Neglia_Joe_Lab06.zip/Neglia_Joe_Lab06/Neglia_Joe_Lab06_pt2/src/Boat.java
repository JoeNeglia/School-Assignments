
public class Boat extends Vehicle {

	public Boat(double efficiency){
		super(efficiency);
	}

	public void printMessage(){
		System.out.println("I am a Boat, VROOM!!!");

	}

}

