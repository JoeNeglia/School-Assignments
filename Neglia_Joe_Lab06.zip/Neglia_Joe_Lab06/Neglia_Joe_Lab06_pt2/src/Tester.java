import java.text.DecimalFormat;
import java.util.Random;

public class Tester {

	public static void main(String[] args) {
		
		DecimalFormat df = new DecimalFormat("0.0000");
		
		final int NUM_VEHICLES = 10;

		int num;

		double effi;

		Vehicle vehicles[] = new Vehicle[NUM_VEHICLES];

		// creates a random class object
		Random r = new Random();

		for (int i = 0; i < NUM_VEHICLES; i++) {

			num = r.nextInt((2) + 1);
			effi = (100) * r.nextDouble();
			
			if (num == 0) {
				vehicles[i] = new Vehicle(effi);
			} 
			else if (num == 1) {
				vehicles[i] = new Car(effi);
			} 
			else {
				vehicles[i] = new Boat(effi);
			}

		}

		// This Loop will Display the Class names
		for (int i = 0; i < NUM_VEHICLES; i++) {
			vehicles[i].printMessage();
		}

		for (int i = 0; i < NUM_VEHICLES; i++) {
			System.out.println(vehicles[i].getName() + " " + df.format(vehicles[i].getEfficiency()));
		}

		Vehicle v = getFirstBelowT(vehicles, 20);

		if (v == null) {
			System.out.println("None of the objects in the array had an efficiency less than 20");
		} 
		else {
			System.out.println("The first object with efficiency less than 20 was " + v.getName() + " with efficiency of " + df.format(v.getEfficiency()));
		}

	}

	private static Vehicle getFirstBelowT(Vehicle[] vehicles, int target) {

		for (int i = 0; i < vehicles.length; i++) {
			if (vehicles[i].getEfficiency() < target)
				return vehicles[i];
		}

		return null;

	}

}