
public class Car extends Vehicle {

	public Car(double efficiency) {
		super(efficiency);
	}

	public void printMessage() {
		System.out.println("I am a Car, VROOM!!!");
	}
}

