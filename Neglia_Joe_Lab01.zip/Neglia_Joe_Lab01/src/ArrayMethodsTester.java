import java.util.Arrays;
import java.util.Random;


public class ArrayMethodsTester {

	//helper method to print an array
	public static void printArray(int[] values) {
		System.out.println(Arrays.toString(values));
	}
	
	public static void main(String[] args) {

		//In your main method you should test your array methods
		//Create an array of size 10
		//****** HERE
		int[] a = new int[10]; //array of size 10
		
		//**** Fill the array with random values (use a loop, and a
		//Random object)
		Random rand1 = new Random();
		for(int i = 0; i < a.length; i++)
			a[i] = rand1.nextInt(10);
		
		int[] b = Arrays.copyOf(a,  a.length);
		int[] c = Arrays.copyOf(a,  a.length);
		int[] d = Arrays.copyOf(a,  a.length);
		int[] e = Arrays.copyOf(a,  a.length);
		int[] f = Arrays.copyOf(a,  a.length);
		int[] g = Arrays.copyOf(a,  a.length);
		int[] h = Arrays.copyOf(a,  a.length);
		int[] i = Arrays.copyOf(a,  a.length);
		int[] j = Arrays.copyOf(a,  a.length);
	
		
		//Now print the array to show initial values
		System.out.println("Initial Array:");
		//note the usage of the "toString()" method here to print the array
		System.out.println(Arrays.toString(a));
		//Could replace the previous line with this:
		//printArray(testValues);
		//blank line
		System.out.println();


		//Test methods below this line.

		//Test of swapFirstAndLast()
		System.out.println("Before call to swapFirstAndLast():");
		printArray(a);
		//swap first and last element
		//this method modifies the array referenced by "testValues"
		ArrayMethods.swapFirstAndLast(a);
		System.out.println("After call to swapFirstAndLast()");
		printArray(a); //printing the same array but it has changed
		System.out.println();

		//continue with tests as you complete methods ...
		
		//part b
		System.out.println();
		System.out.println("After call to shiftRight()");
		ArrayMethods.shiftRight(b);
		printArray(b);
		
		//part c
		System.out.println();
		System.out.println("After call to setEvensToZero()");
		ArrayMethods.setEvensToZero(c);
		printArray(c);
		
		//part d
		System.out.println();
		System.out.println("After call to largerOfAdjacents()");
		ArrayMethods.largerOfAdjacents(d);
		printArray(d);
		
		//part e
		System.out.println();
		System.out.println("After call to removeMiddle()");
		printArray(ArrayMethods.removeMiddle(e));
		
				
		//part f
		System.out.println();
		System.out.println("After call to moveEvensToFront()");
		ArrayMethods.moveEvensToFront(f);
		printArray(f);
		
		//part g
		System.out.println();
		System.out.println("After call to ret2ndLargest()");
		System.out.println(ArrayMethods.ret2ndLargest(g));
		
		//part h
		System.out.println();
		System.out.println("After call to isSorted()");
		System.out.print(ArrayMethods.isSorted(h));
		
		//part i
		System.out.println();
		System.out.println("After call to hasAdjDuplicates()");
		System.out.print(ArrayMethods.hasAdjDuplicates(i));
		
		//part j
		System.out.println();
		System.out.println("After call to hasDuplicates()");
		System.out.print(ArrayMethods.hasDuplicates(j));
				
		
		
		




	}

}
