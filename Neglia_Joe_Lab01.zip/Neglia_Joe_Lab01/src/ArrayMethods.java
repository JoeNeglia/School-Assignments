import java.util.Arrays;
import java.util.Random;


public class ArrayMethods {

	//***NOTE that these methods will change the array itself


	//part a, fill in this method
	public static void swapFirstAndLast(int[] values) {
		// save the first element to a temp var
		int temp = values[0];
		//move the last element to the first position
		values[0] = values[values.length-1];
		// now put the saved first element into the last position
		values[values.length-1] = temp;


	}

	//part b, fill in this method
	public static void shiftRight(int[] values) {
		//a is a placeholder for the last integer in the array
		int a = values[values.length-1];
		//this loop shifts ever number, except the last, to the right one position in the array
		for (int i = values.length - 1; i > 0; i--)
		    values[i] = values[i-1];
		//sets the original last value in the array to the first
		values[0] = a;
	}

	//part c, set all even elements to 0.
	public static void setEvensToZero(int[] values) {
		//this for loop traverses the array and if any number is divisible by two it replaces that value with 0
		for(int i = 0; i < values.length; i++)
			if(values[i] % 2 == 0)
				values[i] = 0;

	}

	//part d, replace each element except the first and last by larger of two 
	//around it
	public static void largerOfAdjacents(int[] values) {
		//this loop traverses the array checking if the elements before and after are larger and if they are it 
		//sets values equal to that number
		for(int i = 1; i < values.length-1; i++) {
			if(values[i] < values[i-1])
				values[i] = values[i-1];
			if(values[i] < values[i+1])
				values[i] = values[i+1];
		}

	}

	//part e, remove middle element if odd length, else remove middle two elements.
	public static int[] removeMiddle(int[] values) {
		
		//if the length of the array is even then this loop creates a new array with the elements until the first middle number
		if(values.length % 2 == 0 ) {
			int[] a = new int[values.length - 2];
			for(int i = 0; i < values.length/2 - 1; i++) {
				a[i] = values[i];
			}
			for(int i = values.length/2+1; i < values.length; i++) {
				a[i-2] = values[i];
			}
			return a;
		}
		//otherwise, this loop will copy until the middle element, then skip the middle element and copy the rest
		else {
			int[] a = new int[values.length - 1];
			for(int i = 0; i < values.length/2; i++) {
				a[i] = values[i];
			}
			for(int i = values.length/2+1; i < values.length; i++) {
				a[i-1] = values[i];
			}
			return a;
		}
	}

	//part f - move all evens to front
	public static void moveEvensToFront(int[] values) {
		//temporary variable to save an integer so it isn't completely erased during the loop
		int temp = 0;
	    int a = 0;
	    //this loop traverses the array and if a value is even it moves it to the beginning of the array
	    for(int i = 0; i < values.length; i++){
	        if(values[i] % 2 == 0){
	            for (int j = i;j > a; j--){
	                temp = values[j - 1];
	                values[j - 1] = values[j];
	                values[j] = temp;
	            }
	            a++;
	        }
	    }
            
	}

	//part g - return second largest element in array
	public static int ret2ndLargest(int[] values) {
		//variables for highest and second highest start at zero
		int highest = 0;
		int secondHighest = 0;

		//this loop traverses the array 
		for (int i = 0; i < values.length; i++) {

		    //finds the highest number
		    if (values[i] > highest) {
		        secondHighest = highest;
		        //sets the new highest
		        highest = values[i];
		    }
		    else if (values[i] > secondHighest) {
		        //replaces the second highest
		        secondHighest = values[i];
		    }
		}
		return secondHighest;
	}


	//part H - returns true if array is sorted in increasing order 
	public static boolean isSorted(int[] values) {
		//this loop traverses the array and tests to see if the values to the right of every element are larger than the last
		for (int i = 0; i < values.length - 1; i++) {
	        if (values[i] > values[i + 1]) {
	            return false;
	        }
	    }
	    return true;
	}
	

	//PART I - return true if array contains 2 adjacent duplicate values
	public static boolean hasAdjDuplicates(int[] values) {
		//this loop traverses the array and tests if it has two of the same value next to one another
		for (int i = 1; i < values.length; i++) {
			  if (values[i] == values[i - 1]) {
			    return true;
			  }
			}
			return false;
	}


	//PART J - return true if array contains 2 duplicate values
	//duplicates need not be adjacent to return true
	public static boolean hasDuplicates(int[] values) {
		//this nested loop checks if any two values in the entire array are the same
		for (int i = 1; i < values.length; ++ i) {
            for (int j = 0; j < i; ++ j) {
                if (values[i] == values[j])
                    return true;
            }
        }
        return false;
	}
}
